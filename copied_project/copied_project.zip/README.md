**#Project Biohazard**

This is a package encompassing the data pipeline for a generic Data Science project.