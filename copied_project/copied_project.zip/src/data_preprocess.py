# -*- coding: utf-8 -*-
"""
Created on Wed Apr 28 14:31:36 2021

@author: rhboerner
"""
#import os
#os.chdir('../ds_project_template/project_biohazard/src/')
import pandas as pd
# import os
# from dbaccess import DataReader#, DataWriter
# from preprocess_util import df_date_mkr,ColEncoder # need to reference parent folder to access this .py file.
pd.options.display.max_columns = 6
#Should change below to PRE-PROD
reader = DataReader('PROD')

# def getSqlFileName():
#     for file in
    
# These SQL queries need to be in a .sql file and called from 
derogDf = reader.fetch_data(sql= '''with u_cte 
                                    as (
                                    select distinct 
                                    ssn, conducted_date as dt, 'PLY' as src from PHX_P_PLY_FCT_TBL where poly_rslt_type_id = 15
                                    UNION
                                    select distinct ssn, EFFECTIVE_START_DATE as dt, 'SECALT' as src from PHX_P_SECALT_FCT_TBL
                                    )
                                    select * from u_cte;'''
                            )
#derogDf.to_csv(r'../data/raw/PHX_PLY_SECALT_derog.csv')# need to make a switch to pull from either this csv or from Oracle directly.

#Load in main source data
src_data = reader.fetch_data(sql='''select SSN_MASTER,  COUNTRY,DISCREPANCY_RECORD, FROM_MONTH, FROM_YEAR from TRAVEL_MASTER2000_2021;''')

#filter and sub select applicable columns
src_data = df_date_mkr(src_data, min_dt='12-01-2016', max_dt='04-01-2020')
src_data = src_data[['SSN_MASTER',  'COUNTRY','DISCREPANCY_RECORD','FROM_MONTH', 'date']]

#Instantiate Encoder class; Encode non-numeric columns; put these function calls in the main() funtcion. 
encoder = ColEncoder(src_data)
encoder.encoded_df.to_csv(r'../data/processed/preprocessed_data_for_model.csv',index=False)# But what if I have multiple data files I need to make?
encoder.dict_writer()

 




dict_writer(r'encoded_dict.pickle',encoder.encoded_dict)

loaded = dict_reader(r'../data/processed/encoded_dict.pickle')        




def main():
    # call above functions, may need a class
    # 1.Need function for initally calling database and creating csv files.
    # 2.Need function to process the csv files and output to processed folder.
    # 3.Think I need mapped dictionaries exported to processed folder to decode values after model runs.
    
    
    
if __name__ == '__main__':

    main()