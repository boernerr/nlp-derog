from sklearn.preprocessing import LabelEncoder
from sklearn import tree
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score
import numpy as np
import pandas as pd
from os import path
import matplotlib.pyplot as plt
import seaborn as sns
import string
import random
# Project Imports
# from opr_derog import DATA_PATH
# from opr_derog.src.preprocess_util import dynamic_bar_plot
from copied_project.src import DATA_PATH
from copied_project.src.randomizer import randomizer

dt_df = pd.DataFrame(pd.read_csv(path.join(DATA_PATH,'raw','dtree.txt'),delimiter='\t'))# This should work, but DATA_PATH won't reload
dt_df.drop(dt_df.columns[0],axis=1, inplace=True)
dt_df.rename(columns=dict(zip(dt_df.columns,['position_cleaned','OCC_SERIES','COST_CODE','TIME_ON_JOB','salaryCpiAdj','category'])),inplace=True)
dt_df.position_cleaned = dt_df.position_cleaned.apply(lambda x: randomizer(x))
dt_df.category = dt_df.category.apply(lambda x: randomizer(x))
dt_df.to_csv(path.join(DATA_PATH,'processed','dtree.csv'))

class DecisionTreeHandler():

    def __init__(self,df):
        self.df = df.copy()# Don't think I actually need this
        self.encoded_dict = dict()
        self.rslt_df = pd.DataFrame() # This is the RESULT of the TEST set. COULD be called test_df instead
        self.df_wPredictions = pd.DataFrame()
        self.encoded_df = self.column_encoder(df[self._train_columns].copy())
        self.iter_df = pd.DataFrame()
        self.clf = None
        self.iterate_clf = None
        self.n_samples = None
        self.X = self.encoded_df.iloc[:, 0:len(self.encoded_df.columns)-1].to_numpy() # All the X cols/rows
        self.y = self.encoded_df.iloc[:, -1].to_numpy() # All the y rows
        self.best_tr_tst_dict = dict() # ***THIS IS BASED ON THE INTITIAL RUN*** dict with all of the BEST tr/tst vals and indices, also predictions too.
        self.iterate_best_tr_tst_dict = dict()
        self.clf_dictionary = dict()

    _train_columns = ['OCC_SERIES', 'COST_CODE', 'salaryCpiAdj', 'category']

    def column_encoder(self, df, create_dict=True):
        for col in df.columns:
            if df[col].dtype == 'object':
                le = LabelEncoder()
                df[col].fillna('None', inplace=True)
                le.fit(list(df[col].astype(str).values))
                df[col] = le.transform(list(df[col].astype(str).values))
                # Create dictionary for de-mapping
                if create_dict:
                    self.encoded_dict = {col: dict(zip(le.transform(le.classes_), le.classes_))}
            else:
                df[col].fillna(-999, inplace=True)

        return df

    # def sample_take(self,n_sample,col='category',rs=101):
    #     """take a sample of a dataframe that is a uniformly distributed sample for each value in a given column E.g.:('category') """
    #     category_std = dict(self.encoded_df.groupby(col)['salaryCpiAdj'].std())
    #     category_mean = dict(self.encoded_df.groupby(col)['salaryCpiAdj'].mean())
    #     criteria_df = self.encoded_df[(self.encoded_df.salaryCpiAdj > (self.encoded_df.category.map(category_mean) - self.encoded_df.category.map(category_std))
    #                                    ) & (self.encoded_df.salaryCpiAdj < (self.encoded_df.category.map(category_mean) + self.encoded_df.category.map(category_std)))]
    #
    #     for category in self.encoded_df.category.unique():
    #         self.uniform_sample_df = self.uniform_sample_df.append(criteria_df.loc[criteria_df.category == category].sample(n=n_sample,replace=True,random_state=rs))#replace allows for rplacement if n_samples > category.shape[0]
    #
    #     #also need to generate converse_sample_df here. This df will be comprised of indexes NOT in uniform_sample_df!
    #     self.converse_sample_df = self.encoded_df.copy().loc[~self.encoded_df.index.isin(self.uniform_sample_df.index)]
    #     return self.uniform_sample_df

    def confusion_matrix(self):
        """Plot confusion matrix for outputs. Need to implement log() of sums, otherwise values are too jumbled."""
        mat = confusion_matrix(self.best_tr_tst_dict['y_test_val'], self.best_tr_tst_dict['prediction'] )
        fig,ax = plt.subplots(figsize = (15,15))
        sns.heatmap(mat, square=True, annot=True, cbar=False)
        plt.xlabel('predicted value')
        plt.ylabel('true value')

    # def _shuffle_data(self):
    #     # This 'shuffles' the data. Ensuring more even distribution of categories when splitting the data.
    #     self.encoded_df = self.encoded_df.sample(frac=1, random_state=0)

    def _merge_preds_selfDf(self,best_dict):
        """Introduce predictions from self.rslt_df BACK into self.df.copy() The purpose is to iteratively develop self.df by modifying categories until adequate."""
        predictions = pd.DataFrame({'predicted':best_dict['prediction']}, index=best_dict['X_test_idx'])
        copy = self.df.copy()
        self.df_wPredictions = copy.merge(predictions, how='left', left_index=True,right_index=True) #   left_on=copy.index, right_on=predictions.index, validate='1:1'
        self.df_wPredictions.predicted = self.df_wPredictions.predicted.map(self.encoded_dict['category'])
        self.df_wPredictions.predicted.fillna('index_not_in_test_set',inplace=True)

    def _assgn_preds(self,best_dict):
        # This is strictly for the TRAINING set! Introduce predictions array back into df & Map encoded columns back to original values.
        idx = best_dict['X_test_idx']
        self.rslt_df = self.df.iloc[idx].copy()
        self.rslt_df['predicted'] = best_dict['prediction']
        self.rslt_df.predicted = self.rslt_df.predicted.map(self.encoded_dict['category'])
        return self.rslt_df

    # Old way that initializes a training set with uniform distributed samples from each df.category. Should not be used unless for testing other functionality.
    def _train_test_split(self,tr_df,tst_df):
        """Create your train/test splits. tr_df=uniform_sample_df, tst_df = converse_sample_df"""
        # df and test_df should actually be sub df's from a 'master' df.
        idx = len(tr_df.columns)-1 # makes add/sub columns modular. Make sure y is the last column!
        self.X_train, self.y_train = tr_df.iloc[:, 0:idx].to_numpy(), tr_df.iloc[:, -1].to_numpy()
        self.X_test, self.y_test = tst_df.iloc[:, 0:idx].to_numpy(), tst_df.iloc[:, -1].to_numpy()

    def get_train_test_splits(self,df, groups, initial_run, n_splits=4):
        idx = len(df.columns) - 1 # make sure df only has 4 columns
        X, y = df.iloc[:, 0:idx].to_numpy(), df.iloc[:, -1].to_numpy()
        clf = tree.DecisionTreeClassifier()
        grp_stratified = StratifiedKFold(n_splits, shuffle=True)# random_state=101
        grp_stratified.get_n_splits(X, y, groups)
        # self.best_X, self.best_y = np.array([]), np.array([])
        best_score = 0
        split = 0
        for tr_idx, tst_idx in grp_stratified.split(X, y, groups):
            X_train, X_test = X[tr_idx], X[tst_idx]
            y_train, y_test = y[tr_idx], y[tst_idx]
            clf.fit(X_train, y_train)
            prediction = clf.predict(X_test)
            score = round(accuracy_score(y_test, prediction), 3)
            # Find me the best scoring train set... DO IT NOW!
            if score > best_score:
                best_score = score
                needed_keys =        ['split','score',  'X_train_val','y_train_val','X_train_idx','X_test_val','y_test_val','X_test_idx','prediction']
                corresponding_vals = [split, score,    X_train,       y_train,        tr_idx,     X_test,          y_test,    tst_idx,        prediction]
                if initial_run:
                    self.best_tr_tst_dict = dict(zip(needed_keys,corresponding_vals))
                    self.clf = clf
                else:
                    self.iterate_best_tr_tst_dict = dict(zip(needed_keys,corresponding_vals))
                    self.iterate_clf = clf
            split += 1

    # def clf_dictionary(self):
    #     #     """Need to store the clf for each iteration of updating said clf. Also should store difference between run metrics."""
    #     #     # {'clf': self.clf_iteration,
    #     #     # 'updated_rows': count_of_newly_classified_unlbls}
    #     #     pass

    def predict_on_entireDf(self, df, clf):
        """ ***BASED ON the CURRENT CLF!!!*** This will allow for manually selecting datasets to iteratively predict and modify existing category values .
            The primary use case is for re-classifying 'unlabeled' to an actual category."""
        iter_df = df[self._train_columns]
        iter_df = self.column_encoder(iter_df, create_dict=False) # create_dict=False means we are not creating a new mapping for values that are encoded.
        idx = len(iter_df.columns)-1 # index of target variable column
        # print(iter_df.columns)
        X = iter_df.iloc[:, 0:idx].to_numpy() # only need the X values for predicting, y is not needed
        prediction = clf.predict(X)
        df['predicted'] = prediction
        df['predicted'] = df['predicted'].map(self.encoded_dict['category'])
        self.iter_df = df# for testing only
        return df

    def set_category_equals_predicted(self, df, category='unlabeled'):
        """The first iteration of predicting on a subset of self.df_wPredictions"""
        pre_ALL_value_counts = df.category.value_counts().to_dict()
        initial_count = df[df.category == category].shape[0]
        df.loc[df.category == category,'category'] = df.predicted # On these conditions, update category value to predicted
        post_ALL_value_counts = df.category.value_counts().to_dict()

        difference = {}
        for cat in pre_ALL_value_counts.keys():
            diff = post_ALL_value_counts[cat] - pre_ALL_value_counts[cat]
            difference[cat] = diff

        category_reduction = difference[category]
        # print(category_reduction)
        print(f'Dataframe has converted {category_reduction * -1} "{category}" values to an ACTUAL category!') # multiply category_reduction by -1 because category_reduction SHOULD be a negative number
        return difference

    def iterative_predict_automated(self, category='unlabeled', num_iters=3): #
        """Once iterative_predict_stepOne has run, run this to iteratively re-assign 'unlabeled' results """
        self.predict_on_entireDf(self.df_wPredictions, clf=self.clf) # taking this out for now: .loc[self.df_wPredictions.category==category]
        for iter in range(num_iters):
            self.set_category_equals_predicted(self.df_wPredictions)  # -> update all ACTUAL values of one category with the PREDICTED values.
            # Now iterate on tr/tst on newly updated df
            self.df_wPredictions = self.column_encoder(self.df_wPredictions[self._train_columns])
        #     self.get_train_test_splits(self.df_wPredictions, groups= np.array(self.encoded_df.category), initial_run=False)
        #     # Need to modify these so that they work on self.df_wPredictions
        #     self._assgn_preds(self.iterate_best_tr_tst_dict)
        #     self._merge_preds_selfDf(self.iterate_best_tr_tst_dict)
        #     print(f'Iteration: {iter} Best split: {self.iterate_best_tr_tst_dict["split"]} {"-" * 5}> Accuracy: {self.iterate_best_tr_tst_dict["score"]}')
        #     self.predict_on_entireDf(self.df_wPredictions.loc[self.df_wPredictions.category == category], clf=self.iterate_clf)
        # return self.df_wPredictions

    def inital_model_run(self):
        """Train/Tst model & Generate predictions. This is the initial run, I.e. the FIRST run."""
        self.get_train_test_splits(self.encoded_df, groups=np.array(self.encoded_df.category), initial_run=True)
        self._assgn_preds(self.best_tr_tst_dict)
        self._merge_preds_selfDf(self.best_tr_tst_dict) # -> creates df_wPredictions
        print(f'Best split: {self.best_tr_tst_dict["split"]} {"-"*5}> Accuracy: {self.best_tr_tst_dict["score"]}')

dt = DecisionTreeHandler(dt_df)
dt.rslt_df.shape
dt.inital_model_run()

dt.predict_on_entireDf(dt.df_wPredictions, clf=dt.clf)

entire_df = dt._assgn_preds_selfDf()
# assign some previous unlabeled to new category
entire_df.loc[(entire_df.category == 'unlabeled'.upper())& (entire_df.predicted !='Index_not_in_test_set'),'category'] = entire_df.predicted
# entire_df.loc[(entire_df.category == 'unlabeled'.upper())& (entire_df.predicted !='Index_not_in_test_set')].predicted.value_counts()
unlabeled = entire_df.loc[entire_df.category == 'unlabeled'].copy()
all_unlabeled = dt.iterative_predict(unlabeled) # this assigns about 10% of unlabeled to an actual category
merge_rows = all_unlabeled[all_unlabeled.predicted != 'unlabeled'].predicted

# Now re introduce all_unlabeled into entire_df and retrain clf.
updated_unlbl = entire_df.merge(merge_rows,how='left',left_index=True,right_index=True)
updated_unlbl.predicted_y.value_counts(dropna=False)
# updated_unlbl[(updated_unlbl.predicted_x != updated_unlbl.predicted_y) & (~updated_unlbl.predicted_y.isna())][['category','position_cleaned','predicted_y']]
updated_unlbl.predicted_y = updated_unlbl.predicted_y.fillna(updated_unlbl.category)
updated_unlbl.drop(columns = 'category', inplace=True)
updated_unlbl.rename({'predicted_y':'category'}, axis=1, inplace=True)
iteration_2_df = updated_unlbl.copy()

dt2 = DecisionTreeHandler(iteration_2_df)
dt2.model_run()
entire_df_2 = dt2._assgn_preds_selfDf()
entire_df_2.loc[(entire_df_2.category == 'unlabeled') & (entire_df_2.predicted !='Index_not_in_test_set'),'category'] = entire_df_2.predicted
unlabeled2 = entire_df_2.loc[entire_df_2.category == 'unlabeled'].copy()
all_unlabeled2 = dt2.iterative_predict(unlabeled2) # this assigns about 10% of unlabeled to an actual category
test2 = all_unlabeled2[all_unlabeled2.predicted !='unlabeled'][['position_cleaned','salaryCpiAdj','predicted']]
merge_rows2 = all_unlabeled2[all_unlabeled2.predicted != 'unlabeled'].predicted
dt = DecisionTreeHandler(dt_df)
dt.model_run()
entire_df = dt._assgn_preds_selfDf()
# assign some previous unlabeled to new category
train_set_unlabeled = entire_df.loc[(entire_df.category == 'unlabeled'.upper()) & (entire_df.predicted !='Index_not_in_test_set')]

entire_df.loc[(entire_df.category == 'unlabeled'.upper())& (entire_df.predicted !='Index_not_in_test_set'),'category'] = entire_df.predicted
unlabeled = entire_df.loc[entire_df.category == 'unlabeled'].copy()
all_unlabeled = dt.iterative_predict(unlabeled)

# Here we are looking at results from running dt on the ENTIRE dataset. Want to re classify as many unlabeled as we can:
all_unlabeled_output = all_unlabeled[all_unlabeled.predicted != 'unlabeled'][['position_cleaned', 'WORKING_TITLE','salaryCpiAdj','category','predicted']]
position_mean  = all_unlabeled_output[(all_unlabeled_output.category == 'unlabeled') & (all_unlabeled_output.predicted != 'unlabeled')].groupby('position_cleaned').salaryCpiAdj.mean().round().to_dict()
unlabeled_for_csv = all_unlabeled_output[(all_unlabeled_output.category == 'unlabeled') & (all_unlabeled_output.predicted != 'unlabeled')][['position_cleaned', 'WORKING_TITLE','category', 'predicted']].copy().drop_duplicates()
unlabeled_for_csv['salaryCpiAdj'] = unlabeled_for_csv.position_cleaned.map(position_mean)
unlabeled_for_csv.to_csv(path.join(DATA_PATH,r'../model/ALL_unlabeled_predicted.csv'),index=False)

# np.unique(all_unlabeled,return_counts=True)

dynamic_bar_plot(entire_df[entire_df.predicted !='Index_not_in_test_set'].predicted.value_counts(dropna = False),type=plt.barh)





dt.rslt_df[(dt.rslt_df.category == 'unlabeled') & (dt.rslt_df.predicted == 'senior_management')][['position_cleaned', 'WORKING_TITLE','salaryCpiAdj']]
labor = dt.rslt_df[(dt.rslt_df.category != 'labor') & (dt.rslt_df.predicted == 'labor')][['position_cleaned', 'WORKING_TITLE','OCC_SERIES','category','predicted','salaryCpiAdj']]


dt.df[(dt.df.OCC_SERIES ==301) ].category.value_counts()
dt.rslt_df[dt.rslt_df.category=='labor'].salaryCpiAdj.mean()

position_mean  = dt.rslt_df[(dt.rslt_df.category == 'unlabeled') & (dt.rslt_df.predicted != 'unlabeled')].groupby('position_cleaned').salaryCpiAdj.mean().round().to_dict()
unlabeled = dt.rslt_df[(dt.rslt_df.category == 'unlabeled') & (dt.rslt_df.predicted != 'unlabeled')][['position_cleaned', 'WORKING_TITLE','category', 'predicted']].copy().drop_duplicates()
unlabeled['salaryCpiAdj'] = unlabeled.position_cleaned.map(position_mean)
unlabeled.to_csv(path.join(DATA_PATH,r'../model/unlabeled_predicted.csv'),index=False)

# EXPLORATION of results
tree.plot_tree(dt.clf)
dt.rslt_df[dt.rslt_df.category != dt.rslt_df.predicted].position_cleaned.value_counts()
dt.rslt_df[dt.rslt_df.position_cleaned == 'STAFF OPERATIONS SPECIALIST'].predicted.value_counts()
ops_labor = dt.rslt_df[(dt.rslt_df.position_cleaned == 'STAFF OPERATIONS SPECIALIST')&(dt.rslt_df.predicted=='labor')]
# dt.rslt_df.loc[191211]
dt.rslt_df[dt.rslt_df.category == dt.rslt_df.predicted].shape[0]/dt.rslt_df.shape[0] # .923, GOOD- this is what is expected!
dt.rslt_df[(dt.rslt_df.COST_CODE==3530)&(dt.rslt_df.category != dt.rslt_df.predicted)][['position_cleaned','category','predicted']]
# clf.get_depth()

################################################## Look at previously unlabeled   #################################################
############################################################################################################################

dt.rslt_df[(dt.rslt_df.category == 'agent') & (dt.rslt_df.predicted != 'agent')][['position_cleaned', 'category', 'key_0','salaryCpiAdj']]
dt.rslt_df.columns
dt.df.columns
dynamic_bar_plot(dt.rslt_df[(dt.rslt_df.category == 'agent') & (dt.rslt_df.predicted != 'agent')].predicted.value_counts(), type=plt.barh, title='Raw Count  Category')

dt.rslt_df[(dt.rslt_df.category == 'unlabeled')].shape[0]
dt.rslt_df[(dt.rslt_df.category == 'operations') & (dt.rslt_df.predicted != 'operations')][['position_cleaned', 'category', 'predicted']]
dt.rslt_df[dt.rslt_df.category != dt.rslt_df.predicted][['position_cleaned', 'category', 'predicted']]

# Look at where categories/predicted DO match
dynamic_bar_plot((dt.rslt_df[dt.rslt_df.category == dt.rslt_df.predicted].category.value_counts() / dt.rslt_df.category.value_counts().values).sort_values(ascending=False), title='Percent Correctly predicted; Category == Predicted')

dynamic_bar_plot(dt.rslt_df[dt.rslt_df.category != dt.rslt_df.predicted].category.value_counts(dropna=False), type=plt.barh, title='Raw Count INcorrectly predicted; Category != Predicted')
dynamic_bar_plot(dt.rslt_df.category.value_counts(dropna=False), type=plt.barh, title='Raw Count  Category')